
@@snap_ids


prompt 
accept dummy char prompt "press <ENTER> to continue"
prompt

@$ORACLE_HOME/rdbms/admin/sprepins


