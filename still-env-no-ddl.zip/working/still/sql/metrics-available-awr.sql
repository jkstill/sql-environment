
-- metrics-available-awr.sql
-- Jared Still 2023
-- call metrics-available.sql to get what is available in AWR

@metrics-available awr

