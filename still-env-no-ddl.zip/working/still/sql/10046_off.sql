alter session set events '10046 trace name context off'
/
