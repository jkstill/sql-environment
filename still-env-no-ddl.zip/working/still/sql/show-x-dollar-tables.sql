
-- show-x-dollar-tables.sql

select kqftanam from x$kqfta
/

