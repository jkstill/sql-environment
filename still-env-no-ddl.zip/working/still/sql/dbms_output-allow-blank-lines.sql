
-- default is word_wrapped
-- setting to wrapped allows printing blank lines

set serveroutput on size unlimited format wrapped
set feed off

exec dbms_output.put_line('')
exec dbms_output.put_line('')
exec dbms_output.put_line('')
exec dbms_output.put_line('')
exec dbms_output.put_line('')
