
-- set term and feed off then back on when calling

col uhostname new_value uhostname noprint

select host_name uhostname from v$instance;


