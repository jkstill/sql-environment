
@@getstat '%'

