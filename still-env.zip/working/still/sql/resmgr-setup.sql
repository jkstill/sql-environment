
set pagesize 100
set linesize 200 trimspool on

