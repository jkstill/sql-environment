
-- metrics-available-ash.sql
-- Jared Still 2023
-- call metrics-available.sql to get what is available in ASH
-- v$sysmetric_history is not constrained by ASH licenses, and not really part of ASH

@metrics-available ash

