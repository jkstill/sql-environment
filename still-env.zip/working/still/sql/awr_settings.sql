select * from dba_hist_wr_control
/
