
column parent_id_plus_exp   format 999
column id_plus_exp      format 990
column plan_plus_exp        format a90
column other_plus_exp       format a90
column other_tag_plus_exp   format a29
column object_node_plus_exp format a14

