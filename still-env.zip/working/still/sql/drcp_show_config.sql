

-- drcp_show_config.sql
-- Jared Still still@pythian.com jkstill@gmail.com
--
-- @print_table_2 'select * from dual'
-- see http://asktom.oracle.com/pls/apex/f?p=100:11:0::::P11_QUESTION_ID:4845523000346615725


@print_table_2 'select * from DBA_CPOOL_INFO'

