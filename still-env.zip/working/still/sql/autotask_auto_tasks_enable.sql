
-- enable automatics stats

exec DBMS_AUTO_TASK_ADMIN.enable


