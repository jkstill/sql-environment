
-- change statspack to level 6

exec statspack.modify_statspack_parameter( i_snap_level => 6 )


