
-- disable automatics tasks
-- useful for test systems with limited resources


exec DBMS_AUTO_TASK_ADMIN.disable

