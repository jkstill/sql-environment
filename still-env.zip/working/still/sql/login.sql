
set timing on time on
set sqlprompt "_USER'@'_CONNECT_IDENTIFIER _PRIVILEGE> "
set serveroutput off


define _editor='/usr/bin/vim -u /home/oracle/working/still/.vimrc'

