
exec statspack.snap;

