

@@clears

set pagesize 0 linesize 200
set term on
set feed off

